require('dotenv').config();

const FeedClient = require('./FeedClient');

const SOCKET_HOST = process.env.SOCKET_HOST;
const SYSTEM_ID = parseInt(process.env.SYSTEM_ID);

const times = {
	requested: null,
	request_received_by_device_rt: null,
	assigned: null,
	first_pi: null,
	arrived: null
};

FeedClient.getAccessToken('fs_integ_test', 'password').then((response) => {
	let ACCESS_TOKEN = response.access_token;
	const options = {
		transports: ['websocket'],
		'force new connection': true,
		extraHeaders: {
			Authorization: `Bearer ${ACCESS_TOKEN}`
		},
		// This is for compatibility with the debugger, which runs through google chrome and does not send headers for WebSockets
		query: `access_token=${ACCESS_TOKEN}`
	};

	let feedClient = new FeedClient(SOCKET_HOST, options);

	feedClient.on('established', (msg) => {
		console.log('INFO: Established a connection to the feed server.');

		let session = msg.body.session;

		times.requested = Date.now();
		feedClient.elevatorRequest(session, {
			session_id: session.session_id,
			source_floor: 11,
			source_door: 'FRONT',
			destination_floor: 4,
			destination_door: 'FRONT',
			system_id: SYSTEM_ID
		});

		feedClient.on('elevator_request_success', (msg) => {
			times.request_received_by_device_rt = Date.now();
			// Once the request is set successfully, we can begin listening for assignment messages
			console.log('INFO: Request successfully sent to the elevator.', msg);
		});

		feedClient.on('elevator_request_assigned', (msg) => {
			times.assigned = Date.now();
			// Request has been processed by the controller and assigned
			console.log('INFO: Elevator Request assigned.', msg);
		});

		feedClient.on('pi_update', (msg) => {
			if (times.first_pi === null) {
				times.first_pi = Date.now();
			}
			console.log('INFO: Received PI update.', msg);
		});

		feedClient.on('elevator_arrived', (msg) => {
			times.arrived = Date.now();
			console.log('INFO: Elevator arrived.', msg);

			console.log('INFO: Time from request to receiving device ACK (s):', (times.request_received_by_device_rt - times.requested) / 1000, `Timestamp: (${times.request_received_by_device_rt})`);
			console.log('INFO: Time from request to assignment (s):', (times.assigned - times.requested) / 1000, `Timestamp: (${times.assigned})`);
			console.log('INFO: Time from request to first PI (s):', (times.first_pi - times.requested) / 1000, `Timestamp: (${times.first_pi})`);
			console.log('INFO: Time from request to arrival (s):', (times.arrived - times.requested) / 1000, `Timestamp: (${times.arrived})`);

			feedClient.destructor();
			process.exit(0);
		});

		feedClient.on('pi_data_not_found', (msg) => {
			console.error('Failed to find PI Data for this request.');
		});
	});

	feedClient.on('disconnect', (msg) => {
		console.log('Disconnected', msg);
	});

	feedClient.on('ecall_error', (msg) => {
		switch (msg.body.error.error_type) {
			case 'user_unauthorized':
				console.error('ERROR: The user is unauthorized to access this system. Please contact Fuzz as the staging data may have become invalid.');
				break;
			default:
				console.error('ERROR: Received an unexpected error, please contact Fuzz.', msg);
				break;
		}

		process.exit(1);
	});

	feedClient.connect().then(() => {
		// We've successfully connected, done
		feedClient.establish(ACCESS_TOKEN);
	}).catch((err) => {
		// We failed to connect
		console.error(err);
	});
}).catch((err) => {
	console.error(err);
});