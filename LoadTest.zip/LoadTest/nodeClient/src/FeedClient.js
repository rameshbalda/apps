const io = require('socket.io-client');
const axios = require('axios');

const API_HOST = process.env.API_HOST;

/**
 * FeedClient
 *
 * A stub client for the Otis eCall Feed Service. This class is responsible for establishing a connection
 * to the feed service and passing on events to event handlers.
 */
class FeedClient
{
	/**
	 * FeedClient constructor
	 *
	 * @param {string} socketUrl
	 * @param {object} options
	 */
	constructor(socketUrl, options) {
		this.socketUrl = socketUrl;
		this.options = options;

		// Mapping of event names to handlers, by default, no events have handlers so that
		// tests have to explicitly define handlers otherwise they will fail. This prevents
		// unexpected events from going unnoticed.
		this.events = {
			"error": null,
			"ecall_error": null,
			"establish": null,
			"established": null,
			"re_establish": null,
			"re_established": null,
			"elevator_request": null,
			"elevator_request_cancel": null,
			"elevator_request_canceled": null,
			"elevator_request_success": null,
			"elevator_request_assigned": null,
			"pi_update": null,
			"elevator_arrived": null,
			"unknown_error": null,
			"session_not_found": null,
			"no_session": null,
			"pi_data_not_found": null,
			"elevator_request_connection_error": null,
			"elevator_request_failed": null,
			"elevator_request_cancellation_failed": null,
			"elevator_request_rejected": null,
			"client_unauthorized": null,
			"user_unauthorized": null,
		};
	}

	static getAccessToken(username, password) {
		return new Promise((resolve, reject) => {
                    resolve(true);
			const config = {
				validateStatus: (status) => {
					return status < 400;
				},
				headers: {
					'X-Client-Id': 'RJ8N8degTLl0bECMuRKMeYneBR5nfJpDbDiEUqhj',
					'X-Client-Secret': '6hcTRuoocy8RyHnSnilzP4OVqFmgSVee94mf5xdV'
				}
			};
                                //FOr ITQA
//                                'X-Client-Id': 'hc4kLDFuGHp97rmvbPiHmScFcxYCCfzZVqvzKpib',// Dev RJ8N8degTLl0bECMuRKMeYneBR5nfJpDbDiEUqhj
//                                'X-Client-Secret': 'Dz5FDXMSFBz2cyIPx9Hm9ueihebcdrbAMyReZl4m' // Dev 6hcTRuoocy8RyHnSnilzP4OVqFmgSVee94mf5xdV  
			const data = {
				username: username,
				password: password,
				grant_type: 'password'
			};
                        //console.log('---->'+ API_HOST);
                        //resolve('token');
			axios.post(`${API_HOST}/oauth/access_token`, data, config).then((response) => {
				if (response.status !== 200) {
					return reject(new Error(`Client credential exchange failed with ${response.status}.`));
				}

				resolve(response.data);
			}).catch(reject);
		});
	}

	/**
	 * Open a connection to the feed service
	 *
	 * @returns {Promise}
	 */
	connect() {
		return new Promise(function (resolve, reject) {
			this.client = io(this.socketUrl, this.options);

			this.bindDefaultHandler();

			this.client.on('connect', () => {
				resolve();
			});
		}.bind(this));
	}

	/**
	 * Bind the FeedClient handler to all listed events
	 */
	bindDefaultHandler() {
		for(let key in this.events) {
			this.client.on(key, this.defaultHandler.bind(this, key));
		}
	}

	/**
	 * The default FeedClient event handler will attempt to find an existing event handler
	 * or throw an Error if one has not been defined. This prevents unexpected exceptions from
	 * going unnoticed.
	 *
	 * @param {string} event
	 * @param {object|string} data
	 */
	defaultHandler(event, data) {
		if (! this.events[event] || this.events[event] === null) {
			console.error(`ERROR: Received unexpected event ${event}.`, data);
			return;
		}

		this.events[event](data);
	}

	/**
	 * Bind a handler to an event
	 *
	 * @param {string} event
	 * @param {function} handler
	 */
	on(event, handler) {
		this.events[event] = handler;
	}

	/**
	 * Establish a session with the Feed Service with an eCall API Token
	 *
	 * @param {string} token
	 */
	establish(token) {
		this.client.emit('establish', {
			body: {
				access_token: token
			}
		});
	}

	/**
	 * Re-establish a session with the Feed Service
	 *
	 * @param {object} session
	 */
	reEstablish(session) {
		this.client.emit('re_establish', {
			body: {
				session: session
			}
		});
	}

	/**
	 * Request an elevator
	 *
	 * @param {object} session
	 * @param {object} request
	 */
	elevatorRequest(session, request) {
            console.log('INFO: Before Requesting to the feed server.');
		this.client.emit('elevator_request', {
			body: {
				session: session,
				request: request
			}
		});
	}

	/**
	 * Clean up the socket and listeners
	 */
	destructor() {
		for(let key in this.events) {
			this.client.removeAllListeners(key);
		}

		this.client.disconnect();
	}
}

module.exports = FeedClient;
