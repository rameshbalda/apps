const io = require("socket.io-client");

// Retrieve args passed to the child process
const [src, dest, simMode] = process.argv.slice(2);
const JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiaktTMTMyMzI0MjVpaWoiLCJlY2FsbGJ1aWxkaW5naWRzIjpbNCw1LDYsNyw4LDksMTAsMTEsMTJdLCJlY2FsbHNjb3BlIjoidXNlciIsImV4cCI6MTg4MzY0NDY2NCwiYXVkIjoiaktTMTMyMzI0MjVpaWoiLCJpc3MiOiJlY2FsbC5vdGlzLmNvbSIsImp0aSI6IjN6MEYxRkI0cTRIMGtZYlIifQ.lu0wIB8bcqIHt3C5aTr9LyJd7MwUpFYsoz8ZKCvJUACWdwlTRhDjrD9DvtDiNLMVYCcW6eXtT8i4AA7yEeljBYiG0nTKsJddJuPJbGKQS4Nrk1KZdurLuh4be5fX4dSf1Y38aJSAUytYypTdWR49MftaCVqNy7GT8UiZ6qCmB0HqPlOgbB0V3aJ0nGkmplfXnMV1KZl1GvWdXi-pxxi3in0kf0bgZhwCQZEy9nwdQyupirQoI93ro2XlATDT5mMmTvUEJsTEAYEVJTP27JYLhYoWd3Ep7F1Kcvfj4sihIKPfAzvUdqqyyuEe8ozTZUhREX1k5LY2n0VsHBO3fES-rw"; // Fallback for testing
console.log("========== DEBUG START ==========");
console.log("Source Floor:", src);
console.log("Destination Floor:", dest);
console.log("Sim Mode:", simMode);
console.log("JWT Token Used:", JWT_TOKEN);
console.log("=================================");

// Socket connection
const socket = io("https://request-elevator-sandbox-eng.ecall.nextgen.otis.com", {
  transports: ["websocket"],
  extraHeaders: {
    Authorization: `Bearer ${JWT_TOKEN}`
  },
  reconnectionAttempts: 3,
  timeout: 10000
});

// Connection events
socket.on("connect", () => {
  console.log("Connected to WebSocket server");

  // Send elevator call after connection
  const payload = {
    src: parseInt(src),
    dst: parseInt(dest),
    simMode: parseInt(simMode)
  };

  console.log("Sending elevator call with payload:", payload);
  socket.emit("ecall", payload, (response) => {
    console.log("Server responded to ecall:", response);
  });
});

socket.on("disconnect", (reason) => {
  console.log("Disconnected. Reason:", reason);
});

socket.on("connect_error", (error) => {
  console.error("Connection Error:", error.message || error);
});

socket.on("error", (error) => {
  console.error("Socket Error:", error.message || error);
});

socket.on("unauthorized", (err) => {
  console.error("Unauthorized:", err.message || err);
});
