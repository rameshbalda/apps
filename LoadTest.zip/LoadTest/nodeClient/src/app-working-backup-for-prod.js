require('dotenv').config();

const FeedClient = require('./FeedClient');

const SOCKET_HOST = process.env.SOCKET_HOST;
const SYSTEM_ID = parseInt(process.env.SYSTEM_ID);
//console.log(SYSTEM_ID);

const times = {
	requested: null,
	request_received_by_device_rt: null,
	got_token: null,
	time_connected: null,
	assigned: null,
	first_pi: null,
	this_pi: null,
	arrived: null,
	connect_fail: null,
	token_fail: null,
	error: null,
	pi_not_found: null
};

 var myArgs = process.argv.slice(2);
 //console.log('myArgs: ', myArgs);
 // if 3rd argument = 1 for sim mode select random floors
 if(myArgs[2]==1)
 {
    var min = Math.ceil(myArgs[0]);
    var max = Math.floor(myArgs[1]);
	var srcFloor = Math.floor(Math.random() * (max - min + 1)) + min;
	var dstFloor = Math.floor(Math.random() * (max - min + 1)) + min;
        // Start For MMS Sytem 41 (Floor 4 not exist)
//	if(srcFloor == 4){
//            srcFloor++;
//        }
//        if(dstFloor == 4){
//            dstFloor++;
//        }
        // End
	// prevent same src & dest
	if(srcFloor==dstFloor)
	{
	   if(srcFloor < max)
	   {
	     srcFloor++;
	   }
	   else if(dstFloor < max)
	   {
	     dstFloor++;
	   }
	   else if(srcFloor > min)
	   {
	     srcFloor--;
	   }
	   else if(dstFloor > min)
	   {
	     dstFloor--;
	   }
	}
 }
 else
 {
    //console.log("Selected Call");
    var srcFloor = myArgs[0];
	var dstFloor = myArgs[1];
        // Start For MMS Sytem 41 (Floor 4 not exist)
//        if(srcFloor == 4){
//            if(dstFloor != 5){
//                srcFloor++;
//            }else{
//                srcFloor--;
//            }
//        }
//        if(dstFloor == 4){
//            if(srcFloor != 5){
//                dstFloor++;
//            }else{
//                dstFloor--;
//            }
//        }
        //End
	console.log(srcFloor);
	console.log(dstFloor);
 }
 
FeedClient.getAccessToken('fs_integ_test', 'password').then((response) => {
	//let ACCESS_TOKEN = response.access_token;
        let ACCESS_TOKEN = response;
        //console.log('access token----'+ACCESS_TOKEN);
        //let JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiNWRkNjY1NDFiMWQ4NTUxNWM0NjE2NDkyIiwiZWNhbGxidWlsZGluZ2lkcyI6WzQyNDAyNjIsMjJdLCJlY2FsbHNjb3BlIjoidXNlciIsImVjYWxsdG9rZW50eXBlIjoiQVBJIiwiZXhwIjoxNTkxMjIyNzExLCJhdWQiOiI1ZGQ2NjU0MWIxZDg1NTE1YzQ2MTY0OTIiLCJpc3MiOiJvdGlzLmRldmVsb3BtZW50IiwianRpIjoiMXZRSXdmbnJ2eTFzMnE4NSJ9.D4B2_4uNmZqSIThg8s25aB9TXZaM4zj_yMZC9qx2JYfsaX3qq2RVxDSGJ7DR_3nZj9P77Un_uONJWxgpAyetTLmEPczjgWsAGIJVaZw4rTSG8Gl0oQ0r9kP3Qgdm03BdjWBAwlx9w73uUFbjOnnEhs5_eaShGOSZvuBHyPPV7BY1HMvDbfwB6k2XDSmYi-ucQk427UFr-HWNJ_X8P1lh4He6rZ-K2IvnGI8NHM45VdvzBf5EcUZU7IxFsqPrzeWkQt1dzajdyN8AEG6S6tjSzDU9dwACxLXBr3lnulI1bkjJEgp6QvvQftdTPPExFqrJpqdsCIGA3anpVPUgmm67nTqN8Ve1YKhLIateJ6re8lXMNmZueJzhekFzroJ159PMD5n7MlFOxttTZBnRBAAuQ2gCNkl1scL5YRTzKDlbbghuKo69PrT49yml1txUuM5wdHg6XFPbYc_VPtoSaAqsaAM7eRck8fn67Q3Zl8ZzPrxHm_Y9Lz2w_myZ2texKe9ciUR85PYU9RjH4vt8_UL54JfrpYmJB0xEL1o8WN71fNijYQEF2XZSv3HVpsTByLz96dHodHRAaHf2LjVnTP6q2yUiOhZqBw-IppiiHgt0gwHqmAkFyvLP4zgRVq7GwE34fcz_dV_M6hubjkBxh_bYawPd9IRTaanWGq91k2POess";
        //let JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiaktTMTMyMzI0MjVpaWoiLCJlY2FsbGJ1aWxkaW5naWRzIjpbNCw1LDYsNyw4LDksMTAsMTEsMTJdLCJlY2FsbHNjb3BlIjoidXNlciIsImV4cCI6MTU2NjU2NTc3MSwiYXVkIjoiaktTMTMyMzI0MjVpaWoiLCJpc3MiOiJlY2FsbC5vdGlzLmNvbSIsImp0aSI6IlJheVdRUTV5SHFBUzdaaFkifQ.e1kSpR-Myi6r9Fx8iMfNmNzzYrkzKurfBdyp9821arM57ZGwsTBGXzoPmIwtXGBJeLGCnm27Vbi1qvMPlnV0OJ5GzmxK3GaudvcCRg9mbLi_KqPifGIJEE5QSDplNDYV1PX7FxlOaR6xf4TtQRakbVE4YOJ1AoDxanGQUQ7LPtqDCu-jmeaO_-I07-HXjtPT69E60SFnbrtHW17zTY1dhCLQdTDaOd5m9e_g4bfwfIzaJHUxl4_GSoyZy6lOaeZUjsmXUQZT0WE7bPvi1J1Bz-bsabkdnLluu6TqN5nIhTPJ-csx6U6EaWmXmNd2ZcK-K3AvHI0qfYpSMEdZrCd87UjvVSQjo9_tCYrUbs2vBTbb4NJwQs_ion-ZgFkBHPuRhT4ylljb4zQF6KiAQ8IoPq39uBEztt-QvutdGQx9eJGcu43haEb2y7rp6xhC5tYndF67Pds16c2F0D2ngCkYUOmkTXwDv3zeFb2qKpUgzIRKij-_S8M-MCXjLFewX9gk3jE1MYzOdCcbH1tk8QqoGVZbWcR3IxF08_yhT_TuULIpEzTfxdEG5abHuDk-iRHCKwhaNHdZ6LpaQIiq_VaLPXGIlrjhhHGE5UR6QXm-d3KOxlrQN3F73BIqmsi9Ulh2BR7qPg_rv_maXZYM0suC98XzGs6VeZautARJRW86oOQ";
        //let JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiaktTMTMyMzI0MjVpaWoiLCJlY2FsbGJ1aWxkaW5naWRzIjpbNCw1LDYsNyw4LDksMTAsMTEsMTJdLCJlY2FsbHNjb3BlIjoidXNlciIsImV4cCI6MTcyMzk3MTQ0MCwiYXVkIjoiaktTMTMyMzI0MjVpaWoiLCJpc3MiOiJlY2FsbC5vdGlzLmNvbSIsImp0aSI6IkdyZ3RTdDNBZWRGWjRRaTAifQ.m0FrQtl0kd1rjLKwHjIhvtr_jHJGDMc2c0kkid3tGba4TXMowxl_6FQ4rTBgz6b690s4cwqNfue5wx60l97TKrzLQKmphGv_rjGfkU8BtdtWEfRQZohgDtCSdRHVDbrl5jW2mIURRh8qxW8bcbfQveVZ85hRXNNE_1CW4VDeSn9X-RAHor-qaZbKyCYV5ac9Csowcp2qsWD5pQcuQZ3C9rdCFX0BqzPEJB3NdaqD0LEbSUdJmv1QbSQB4LZ7G8xr9Uwgmm6YCp7NOrk3zEwYEr6Q7RbRKkQbCRJFnjQseBW8NJuHX7STOJW_VxNjFM04iifrVHL3LSPvEYHzsgzGXAS4dEYJUEtnG91lmDqRzV3-C-P_WexpwnSpDrmOBh4CI1yx5HwJA2VZ4x_xRKbzMiRTW5LMOoRiEZAhU9Hs-8-hhgwWmEyQt4DCJxi26LAuRT4HvTYeXGQw3M-2DiwwlJkMzZEPdYuO1fn1u5-Ahl3tEV1WkzsAJNlFmsGlTRjv0hcNm_WXvYGCFMq7-waHbdGsBJ-yYSuG4ggHdlRMGpcQfVGhQFeqlYb-G8sLlxsPFwohJFuihL4chvMEXW1rxggTKhl5yPPPdQH-8ir6lIYyZhCy8bCxrKbIOl1Sd6kssuM9n0H2ai_sDG9Q6O1kgmErbqIFyCDemhv-iaKviIs";
        //let JWT_TOKEN = "sss";
        //let JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiNWQ1ZmMxM2NiMWQ4NTUyYzM4NmI5N2QwIiwiZWNhbGxidWlsZGluZ2lkcyI6WzQyNDAyNTMsNDI0MDI1NCw0MjQwMjU3LDQyNDAyNTksNDI0MDI2MSw0MjQwMjkwLDQyNDAyODksNDI0MDI1Nl0sImVjYWxsc2NvcGUiOiJ1c2VyIiwiZWNhbGx0b2tlbnR5cGUiOiJBUEkiLCJleHAiOjE2MTA1NjA5OTMsImF1ZCI6IjVkNWZjMTNjYjFkODU1MmMzODZiOTdkMCIsImlzcyI6Im90aXMuZGV2ZWxvcG1lbnQiLCJqdGkiOiJMdVdQVzloR3NUYlRHcUtMIn0.oWZyKKw8Z6OAp1x7Mov4RvYq-OFtNop7ziuSEDY_Ht_-RJC1ov6e7UGjDyYrb4_b0nUNd6EK9hmBKbKhuuGN_5_2ojbtdY__X39ip_shl-6TriYHaHyRn93ox2AwGQ8NzffTNe2DCZQxTWJ6nj1fHAPRz-hgAyEs1tIeui5GD4oLRFzJVuvQRVYne8tJgRQzOqF6O5WbimK7nZAuwZF4T-o1iAijw01CcSwxzuOwouoz70vUOFM5GTlQlnUFvbWuhTq3Prb4hA6ESEW9tGXopm5OPyQs5HUcfDd-AHAZ8thYViJeF6z9_D5utVFUSPxMCzI1jQ3zOWGSubx4quWK3tI3yoc_12HOOxglIHpBoE1IA9ZdeLXVAaZgq5Lj1gUNOciT7oa3ZhFIomRsfKyzpj61PdMzdStiAV4lKps1RrO8Lu0lqYDn2m0kqpCMZ7W3sVUuIl7bxCj4JeN4Kxfjxp7Lf3CQfQond9dZNy6r9wgTR7SLD9bzKw3tNbSdzLlmWL8dEzw9xtlRCNnqaiUcVcEEW03iCS6aZXSkKACR-DR9MHf2FWN5TMXw8ZwagY5N3-hsA9PK1Ml8pGvMBSuO4VEvM8Ddm9Kg2NoP5CVDokUA-rNn5brVc2DgCPIjxV6gv6dpSfcRIJm8ztxQvHym3HHvAHuejbXVc8QUHsLB6U0";
	let JWT_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJlY2FsbHN1YnNjcmlwdGlvbmlkIjoiNjA3NDg2MjRkYjBhZDczOTQwNzdiNDEzIiwiZWNhbGxidWlsZGluZ2lkcyI6WzQyNDAyNThdLCJlY2FsbHNjb3BlIjoidXNlciIsImV4cCI6MTc0OTUwOTU1MSwiYXVkIjoiNjA3NDg2MjRkYjBhZDczOTQwNzdiNDEzIiwiaXNzIjoib3Rpcy5lbmdnLnNhbmRib3giLCJqdGkiOiJCdDU3bHRkaFJLekIzaU9yIn0.JK8DdFdyF8WXi9hFIEAV5_Qg2Xs2mXjXvU-TJIUeqkw5T-Z-_TCqmJlgOhZTNpITSAMuvTJvexFuRbvMvL6P0Y_JACm_TpZ3FXfqNImQCv7i5lbnH5DKi2iRhVmnVudFFBFubbXMUuDje_VreuvBq9M59OdDXboxQPAGuqEftsx9dRyUO434nVGl80Hr4pprioEPVxOcgJpHm5qqdisQDBS9MJmrIRGGhvaEuTrzDRHxJyL0JeJj_ZKDMWboS-g3KMIJucCJljcjpt6IpGyD3aYJk1E18DnpK9lvzXXTonO7Ca9hlk9XpkeFWNlt3JAUonlJ5yD52udsuovI_P05Qg";
    const options = {
		'transports': ['websocket'],
		'force new connection': true,
		'extraHeaders': {
			//Authorization: `Bearer ${ACCESS_TOKEN}`
                        Authorization: JWT_TOKEN
		},
		// This is for compatibility with the debugger, which runs through google chrome and does not send headers for WebSockets
		//uery: `access_token=${ACCESS_TOKEN}`
	};
	times.got_token = Date.now();
	//console.log("pass, " + ACCESS_TOKEN + ',token     ,' + times.got_token);


	let feedClient = new FeedClient(SOCKET_HOST, options);

	feedClient.on('established', (msg) => {
		console.log('INFO: Established a connection to the feed server.');

		let session = msg.body.session;
                //var sourceFloor =
                var source_door = 1;
		times.requested = Date.now();
		feedClient.elevatorRequest(session, {
			session_id: session.session_id,
			source_floor: parseInt(srcFloor),
			source_door: 'FRONT',
			destination_floor: parseInt(dstFloor),
			destination_door: 'FRONT',
			system_id: SYSTEM_ID,
                        //call_type: "EXTENDED_SERVICE",
                       /* badgeCredential: {
                            hex_value : "B47C9912A0",
                            badge_format: {
                                length: 36
                            }
                        }*/
                        //walk_time: 0,
                        //walk_speed: 0,
                        
		});

		feedClient.on('elevator_request_success', (msg) => {
			times.request_received_by_device_rt = Date.now();
			// Once the request is set successfully, we can begin listening for assignment messages
			//console.log('INFO: Request successfully sent to the elevator.', msg);
			console.log("pass," + ACCESS_TOKEN + ',dm_ack    ,' + times.requested + ',' + times.request_received_by_device_rt + ',' + srcFloor + ',' + dstFloor + ',' + (times.request_received_by_device_rt - times.requested) / 1000);
		});

		feedClient.on('elevator_request_assigned', (msg) => {
			times.assigned = Date.now();
			// Request has been processed by the controller and assigned
			//console.log('INFO: Elevator Request assigned.', JSON.stringify(msg));
			//console.log('INFO: Time from request to receiving device ACK (s):', (times.request_received_by_device_rt - times.requested) / 1000, `Timestamp: (${times.request_received_by_device_rt})`);
			console.log("pass," + ACCESS_TOKEN + ',assignment,' + times.requested + ',' + times.assigned + ',' + srcFloor + ',' + dstFloor + ',' + (times.assigned - times.requested) / 1000 + "," + msg.body.session.assignment.group_id + "-" + msg.body.session.assignment.car_id);
			
			//console.log(msg);
			
			//var fs = require('fs')
			//fs.appendFile('D:\node client\log.txt', (times.assigned - times.requested) / 1000, function (err) {
			//  if (err) {
			//	console.log("log failed");
			//  } else {
			//	console.log("log ok");
			//  }
			//})			
			
			//feedClient.destructor();
			//process.exit(0);
		});
		
		
		feedClient.on('pi_update', (msg) => {
			if(times.first_pi === null) {
				times.first_pi = Date.now();
			}
			times.this_pi = Date.now();
			console.log("pass," + ACCESS_TOKEN + ',pi        ,' + times.assigned + ',' + times.this_pi + ',' + srcFloor + ',' + dstFloor + ',' + (times.this_pi - times.assigned) / 1000 + "," + msg.body.current_floor_label + "," + msg.body.direction);
			//console.log(msg);
			
		});
		
		feedClient.on('elevator_arrived', (msg) => {
			times.arrived = Date.now();
			console.log("pass," + ACCESS_TOKEN + ',arrival   ,' + times.assigned + ',' + times.arrived + ',' + srcFloor + ',' + dstFloor + ',' + (times.arrived - times.assigned) / 1000);
			//console.log(msg);
			feedClient.destructor();
			process.exit(0);
		});
		
		feedClient.on('pi_data_not_found', (msg) => {
			time.pi_not_found = Date.now();
			console.log("fail," + ACCESS_TOKEN + ',piNotFound,' + times.assigned + ',' + times.pi_not_found + ',' + srcFloor + ',' + dstFloor + ',' + (times.pi_not_found - times.assigned) / 1000);
			//console.log(msg);
			feedClient.destructor();
			process.exit(0);
		});
	});

	feedClient.on('disconnect', (msg) => {
		//console.log('Disconnected', msg);
		times.error=Date.now();
		console.log("fail," + ACCESS_TOKEN + ',disconnect,' + times.requested +  ',' + times.error + ',' + srcFloor + ',' + dstFloor + ',' + (times.error - times.requested) / 1000 + "," + msg);
		//console.log(msg);
		feedClient.destructor();
		process.exit(0);
	});
	
	// refer to feed service\src\application.js
	feedClient.on('piupdate_ems_error', (msg) => {
		times.error = Date.now();
		console.log(msg);
		console.log("fail," + ACCESS_TOKEN + ',pierror   ,' + times.requested + ',' + times.error + ',' + srcFloor + ',' + dstFloor + ',' + (times.error - times.requested) / 1000 + "," + msg.body.error.code);
	});
	
	feedClient.on('vte_error', (msg) => {
		times.error = Date.now();
		console.log(msg);
		console.log("fail," + ACCESS_TOKEN + ',vteerror  ,' + times.requested + ',' + times.error + ',' + srcFloor + ',' + dstFloor + ',' + (times.error - times.requested) / 1000 + "," + msg.body.error.error_type);
	});

	feedClient.on('ecall_error', (msg) => {
	    times.error = Date.now();
		console.log(msg);
		switch (msg.body.error.error_type) {
			case 'user_unauthorized':
				console.log('ERROR: The user is unauthorized to access this system. Please contact Fuzz as the staging data may have become invalid.');
			    console.log("fail," + ACCESS_TOKEN + ',error     ,' + times.requested + ',' + times.error + ',' + srcFloor + ',' + dstFloor + ',' + (times.error - times.requested) / 1000 + ",unauthorized");
			
				break;
			default:
				//console.error('ERROR: Received an unexpected error, please contact Fuzz.', msg);
				console.log("fail," + ACCESS_TOKEN + ',error     ,' + times.requested +  ',' + times.error + ',' + srcFloor + ',' + dstFloor + ',' + (times.error - times.requested) / 1000 + "," + msg.body.error.error_type);
				break;
		}

		feedClient.destructor();
		process.exit(0);
		//process.exit(1);
	});

	feedClient.connect().then(() => {
		// We've successfully connected, done
		times.time_connected = Date.now();
		console.log("pass," + ACCESS_TOKEN + ',connected ,' + times.got_token + ',' + times.time_connected + ',' + srcFloor + ',' + dstFloor + ',' + (times.time_connected - times.got_token) / 1000);
		//feedClient.establish(ACCESS_TOKEN);
	}).catch((err) => {
		time.connect_fail = Date.now();
		// We failed to connect
		console.log("fail," + ACCESS_TOKEN + ',connected ,' + times.got_token + ',' + times.connect_fail + ',' + srcFloor + ',' + dstFloor + ',' + (times.connect_fail - times.got_token) / 1000);
		//console.error(err);
	});
}).catch((err) => {
	times.token_fail = Date.now();
	// We failed to connect
	console.log("fail," + "tokenNull" + ',token     ,' + times.token_fail);
	console.error(err);
});