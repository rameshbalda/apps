# ECall Node Client

Copyright © 2017 Otis Elevator Company. All rights reserved.  
Part # AAA31738AAA

This is a NodeJS client to the Otis ECall application.

## RUNNING FROM ZIP

* Install Node v6.9.1 - https://nodejs.org/en/download/
* Edit the `proj_root/.env` file (staging is configured by default)
* Run the client with `node src/app.js` or `npm run start`


## SETUP

Grab the dependencies:

	$ yarn install

Copy the example env vars and edit to appropriate values:

	$ cp .env.example .env


## RUNNING IN DEV

    $ yarn start


## DEBUGGING
To debug via app.js:

    $ yarn run debug