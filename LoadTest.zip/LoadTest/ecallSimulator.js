// eCall Simulator
// Enters eCalls based on Compass Passenger List file, or by specified parameters

// Prerequisites: Install node and node-scheduler and nodefly for garbage collection monitoring
//https://nodejs.org/en/download/
// npm install node-schedule

// Run with Compass passenger list file
// node eCallsimulator.js --f=FILENAME

// Run with Compass passenger list file for times only, but specify min and max floor for random calls
// node eCallsimulator.js --f=FILENAME --min=minFloor --max=maxFloor

// Run in random call mode at fixed interval
// node eCallsimulator.js --rand=1 --min=minFloor --max=maxFloor --int=intervalInseconds

// Run random call once
// node eCallsimulator.js --rand=1 --min=minFloor --max=maxFloor

// Run specified call once
// node eCallsimulator.js --src=src --dst=dst


console.log("info, eCall Simulator")
var fs = require('fs');
const args = require('yargs').argv;
var schedule = require('node-schedule');
var simMode = 0;
var compassListMode = 0;
var minFloor = 0;
var maxFloor = 0;
var delayTime = 0;
var calls = [];
var keypress = require('keypress');
keypress(process.stdin);
var tim1;

require('nodefly-gcinfo').onGC(function(usage, type, flags){
    console.log("GC Event Occurred");
    console.log("Heap After GC:",usage, type, flags);
});

process.stdin.on('keypress', function (ch, key) {
	//console.log('key press',key);
    if (key && key.ctrl && key.name == 's') {
        clearInterval(tim1);
		console.log('info, stopping future calls');
	}
	if (key && key.ctrl && key.name == 'c') {
		console.log('info, exiting simulator');
		process.exit(0);
	}
});

process.stdin.setRawMode(true);
	
if(args.f && args.min && args.max)
{
   compassListMode = 2;
   console.log("info, Compass Pax List for time intervals with Random Calls from " + args.min + " to " + args.max);
}
else if(args.f && !args.min && !args.max)
{
   compassListMode = 1;
   console.log("info, Compass Pax List");
}
else if(args.rand=1 && args.min && args.max && !args.int)
{
   simMode = 2;
   console.log("info, Random Call between floors " + args.min + " and " + args.max + "Once");
   console.log("info, Ctrl-S to stop future calls prior to exiting with Ctrl-C");
}
else if(args.rand=1 && args.min && args.max && args.int)
{
   simMode = 1;
   console.log("info, Random Calls between floors " + args.min + " and " + args.max + " at Interval " + args.int + " seconds");
   console.log("info, Ctrl-S to stop future calls prior to exiting with Ctrl-C");
   console.log("status,session,msg,start,end,src,dst,delta,extra1,extra2");
}
else if(args.src && args.dst)
{
   simMode = 3;
   console.log("info, Single Call from " + args.src + " to " + args.dst);
}
else
{
    console.log("Invalid mode");
    //process.exit();
    simMode = 3;
}

if (compassListMode > 0)
{
    //var array = fs.readFileSync("D:\ecallSimulator\Bitexco_LR_up.pro").toString().split("\n");
	var array = fs.readFileSync(args.f).toString().split("\n");
	var startTime = (new Date).getTime();
	var ind = 0;
	var ind2 = 0;
	console.log(startTime)
    for (i in array) {
        //console.log(array[i]);
        var res = array[i].split(/[ ,]+/);
        // if passenger record then schedule request
        if (res[0] == 'P') {
            // print out starting time, src floor, dst floor
            console.log('i:' + i + ' T=' + res[1] + ',' + res[2] + ',' + res[3] + '\n');

			calls[ind2] = i;
			//calls.push(call);
            // schedule ecall according to time and parameters from compass passenger list file
			var j = schedule.scheduleJob((startTime + res[1]*1000), function(){
				//var call = calls.splice(j, 0);
				var res2 = array[calls[ind]].split(/[ ,]+/);
				//eCall(calls[ind,0], calls[ind,1], 0);
				
				// calls per list
				if(compassListMode==1)
				{
					eCall(res2[2],res2[3],0);
				}
				// random calls, but use times from pax list file
				else if (compassListMode==2)
				{
					eCall(args.min,args.max,1);
				}
				//console.log('Index:' + ind + ":" + ((new Date).getTime() - startTime));
				ind++;
			});
			ind2++;
            //break;
        }
    }
}

if (simMode > 0)
{
	// calls at specified interval
	if(simMode ==1)
	{
		tim1 = setInterval(eCall, args.int * 1000, args.min, args.max, 1);
	}
	else if(simMode == 2)
	{
		eCall(args.min, args.max, 1);
	}
	else if(simMode == 3)
	{
		eCall(args.src, args.dst, 0);
	}
}


function eCall(src, dest, simMode) {
    const child_process = require('child_process');
	var worker_process = child_process.fork("C:\\LoadTest\\nodeClient\\src\\app.js", [src, dest, simMode], { cwd: 'C:\\LoadTest\\nodeClient\\' });
    //var worker_process = child_process.fork("D:\\debug-tools\\eCall Simulator Load Test\\nodeClient\\src\\app.js", [src, dest, simMode], { cwd: 'D:\\debug-tools\\eCall Simulator Load Test\\nodeClient\\' });
}
